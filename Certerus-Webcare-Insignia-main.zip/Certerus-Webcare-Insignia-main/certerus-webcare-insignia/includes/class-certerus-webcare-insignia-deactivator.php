<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://www.certerus.com/
 * @since      1.0.0
 *
 * @package    Certerus_Webcare_Insignia
 * @subpackage Certerus_Webcare_Insignia/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Certerus_Webcare_Insignia
 * @subpackage Certerus_Webcare_Insignia/includes
 * @author     Certerus <desarrollo@certerus.com>
 */
class Certerus_Webcare_Insignia_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
