<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://https://www.certerus.com/
 * @since      1.0.0
 *
 * @package    Certerus_Webcare_Insignia
 * @subpackage Certerus_Webcare_Insignia/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Certerus_Webcare_Insignia
 * @subpackage Certerus_Webcare_Insignia/includes
 * @author     Certerus <desarrollo@certerus.com>
 */
class Certerus_Webcare_Insignia_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'certerus-webcare-insignia',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
