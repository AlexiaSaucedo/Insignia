<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://www.certerus.com/
 * @since      1.0.0
 *
 * @package    Certerus_Webcare_Insignia
 * @subpackage Certerus_Webcare_Insignia/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Certerus_Webcare_Insignia
 * @subpackage Certerus_Webcare_Insignia/includes
 * @author     Certerus <desarrollo@certerus.com>
 */
class Certerus_Webcare_Insignia_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
