# Certerus Webcare Insignia

Plugin para agregar por medio de un Shortcode, una insignia de Certerus. 

## Instalación
1. Descargar el plugin y activarlo en la página
2. Agregar el shortcode
```bash
[certerus_insignia]
```
