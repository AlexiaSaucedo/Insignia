<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://www.certerus.com/
 * @since      1.0.0
 *
 * @package    Certerus_Webcare_Insignia
 * @subpackage Certerus_Webcare_Insignia/admin/partials
 */

 if ( ! defined( 'WPINC' ) ) die;

?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">
    <h2>Certerus Webcare <?php esc_attr_e('Configuración', 'plugin_name' ); ?></h2>

    <form method="post" name="<?php echo $this->plugin_name; ?>" action="options.php">
    <?php
        //Grab all options
        $options = get_option( $this->plugin_name );

        $show_badge = ( isset( $options['show_badge'] ) && ! empty( $options['show_badge'] ) ) ? 1 : 0;
        $style_badge = ( isset( $options['style_badge'] ) && ! empty( $options['style_badge'] ) ) ? 1 : 0;
        //$example_text = ( isset( $options['example_text'] ) && ! empty( $options['example_text'] ) ) ? esc_attr( $options['example_text'] ) : 'default';
    
        settings_fields($this->plugin_name);
        do_settings_sections($this->plugin_name);

    ?>

    <!-- Checkbox: Mostrar Insignia -->
    <fieldset>
        <label for="<?php echo $this->plugin_name; ?>-show_badge">
            <input type="checkbox" id="<?php echo $this->plugin_name; ?>-show_badge" name="<?php echo $this->plugin_name; ?>[show_badge]" value="1" <?php checked( $show_badge, 1 ); ?> />
            <span> Mostrar insignia de Certerus</span>
        </label>
    </fieldset>

    <fieldset>
        <h3>Estilo según el Fondo</h3>    

        <label for="<?php echo $this->plugin_name; ?>-light">
            <input type="radio" id="<?php echo $this->plugin_name; ?>-light" name="<?php echo $this->plugin_name; ?>[style_badge]" value="1" <?php checked( $style_badge, 1 ); ?> />
            <span> Claro</span>
        </label>
        <label for="<?php echo $this->plugin_name; ?>-dark">
            <input type="radio" id="<?php echo $this->plugin_name; ?>-dark" name="<?php echo $this->plugin_name; ?>[style_badge]" value="0" <?php checked( $style_badge, 0 ); ?>/>
            <span> Oscuro</span>    
        </label>
    </fieldset>


    <!-- Text -->

	<?php submit_button( __( 'Guardar cambios', 'plugin_name' ), 'primary','submit', TRUE ); ?>
    </form>
</div>
